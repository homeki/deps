#include <windows.h>

typedef __int8 __int8_t;
typedef unsigned __int8 __uint8_t;
typedef __int16 __int16_t;
typedef unsigned __int16 __uint16_t;
typedef __int32 __int32_t;
typedef unsigned __int32 __uint32_t;
typedef __int64 __int64_t;
typedef unsigned __int64 __uint64_t;
